import React, { useEffect, useState } from 'react'

const Blog = () => {
  const [email, setEmail] = useState([])
  const [password, setPassword] = useState([])
  const [getEmail, setGetEmail] = useState([])
  const [getPassword, setGetPassword] = useState([])

  useEffect(() => {
    const storedEmail = localStorage.getItem('loginemail')
    const storedPassword = localStorage.getItem('loginpassword')

    const streetEmail = localStorage.getItem('signemail')
    const streetPassword = localStorage.getItem('signpassword')

    if (storedEmail && storedPassword) {
      setEmail(storedEmail)
      setPassword(storedPassword)
    }

    setGetEmail(streetEmail)
    setGetPassword(streetPassword)
  }, [])

  return (
    <div>
      <div>LoginEmail: {email}</div>
      <div>LoginPassword: {password}</div>
      <div>
        <h2>SignupEmail: {getEmail}</h2>
        <h2>SignUppassword: {getPassword}</h2>
      </div>

      <div className="grid md:grid-cols-3 grid-cols-1 max-w-6xl mx-auto justify-center items-center my-10 gap-5">
        <div className="bg-white h-[373px] w-[370px] text-gray-400  rounded-[30px] border border-[#bee1e6] hover:border-[#bee1e6] hover:border-2 md:mb-10 hover:shadow-xl pb-5 relative hover:translate-y-1 hover:duration-1000">
          <div className="flex justify-center items-center my-5">
            <h3 className="rounded-full  text-xl text-white font-semibold py-10 px-12 bg-[#bee1e6] ">
              images
            </h3>
          </div>
          <p className="text-black text-sm mx-6	font-nunito  font-bold	leading-[19px]">
            Title
          </p>
          <div>
            <div className="flex flex-col px-6 my-4">
              <p className="text-black text-sm py-6	font-nunito  font-bold	leading-[19px]">
                Description
              </p>
              <p className="text-custom-gray text-xl	my-3 font-normal	font-nunito leading-[16px]">
                category
              </p>
              <p className="text-black text-sm py-6	font-nunito  font-bold	leading-[19px]">
                Author
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Blog
