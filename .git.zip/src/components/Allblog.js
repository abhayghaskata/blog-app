import React, { useState } from 'react'

const Allblog = () => {
  const [title, setTitle] = useState([])
  const [description, setDescription] = useState([])
  const [img, setImg] = useState([])
  const copy = img

  const handleSubmit = () => {
    console.log('Title>>>>', title)
    setTitle('')
    console.log('description>>>>', description)
    setDescription('')
    console.log('img>>>>', img)
    setImg('')
  }

  return (
    <div>
      <div className="max-w-xl mx-auto  my-10 rounded-xl bg-[#3874cb]">
        <div className="flex justify-center flex-col py-12 w-1/2 mx-auto">
          {/* <div>
            <img src="" alt="" />
          </div> */}
          <div className="flex flex-col my-2">
            <label htmlFor="" className="text-white ">
              Title
            </label>
            <textarea
              name=""
              id=""
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              cols="30"
              rows="2"
              placeholder="Add Title"
              className=" outline-none p-3"
            ></textarea>
          </div>

          <div className="flex flex-col my-2">
            <label
              className=" text-white "
              htmlFor=""
              placeholder="enter your description"
            >
              Textarea
            </label>
            <textarea
              name=""
              id=""
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              cols="30"
              rows="5"
              placeholder="Enter your description"
              className=" outline-none p-3"
            ></textarea>
          </div>

          <div className="flex flex-col my-2">
            <label htmlFor="" className="text-white ">
              Images
            </label>
            {/* <textarea
              name=""
              id=""
              cols="30"
              rows="2"
              value={img}
              onChange={(e) => setImg(e.target.value)}
              placeholder="Drop your link"
              className=" outline-none p-3"
            ></textarea> */}

            <input
              type="file"
              value={img}
              onChange={(e) => setImg(e.target.value)}
              accept="image/*"
            />
          </div>

          <div className="flex flex-col my-2">
            <button
              className="text-white font-semibold px-3 py-2 bg-black rounded-lg w-1/3 mx-auto hover:text-[#3874cb]"
              onClick={handleSubmit}
            >
              Submit
            </button>
          </div>

          <div>
            <img src={copy} alt="" />
          </div>
        </div>
      </div>
    </div>
  )
}

export default Allblog
