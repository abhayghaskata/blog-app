import React from 'react'

const Home = () => {
  return (
    <div>
      <div className="grid md:grid-cols-3 grid-cols-1 max-w-6xl mx-auto justify-center items-center my-10 gap-5">
        <div className="bg-white h-[373px] w-[370px] text-gray-400  rounded-[30px] border border-[#bee1e6] hover:border-[#bee1e6] hover:border-2 md:mb-10 hover:shadow-xl pb-5 relative hover:translate-y-1 hover:duration-1000">
          <div className="flex justify-center items-center my-5">
            <h3 className="rounded-full  text-xl text-white font-semibold py-10 px-12 bg-[#bee1e6] ">
              images
            </h3>
          </div>
          <p className="text-black text-sm mx-6	font-nunito  font-bold	leading-[19px]">
            Title
          </p>
          <div>
            <div className="flex flex-col px-6 my-4">
              <p className="text-black text-sm py-6	font-nunito  font-bold	leading-[19px]">
                Description
              </p>
              <p className="text-custom-gray text-xl	my-3 font-normal	font-nunito leading-[16px]">
                category
              </p>
              <p className="text-black text-sm py-6	font-nunito  font-bold	leading-[19px]">
                Author
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home
