import * as React from 'react'
import AppBar from '@mui/material/AppBar'
import Box from '@mui/material/Box'
import Toolbar from '@mui/material/Toolbar'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import IconButton from '@mui/material/IconButton'
import MenuIcon from '@mui/icons-material/Menu'
import { useHistory } from 'react-router-dom'
import ContactMailIcon from '@mui/icons-material/ContactMail'
import LoginIcon from '@mui/icons-material/Login'
import LogoutIcon from '@mui/icons-material/Logout'

export default function Header() {
  const [isShown, setIsShown] = React.useState(false)

  const handleLogout = () => {
    localStorage.removeItem('loginpassword')
    history.push('/login')

    // localStorage.removeItem('signpassword')
  }

  const handleSide = (event) => {
    setIsShown((current) => !current)
  }
  const history = useHistory()

  const HandleLogin = () => {
    history.push('/login')
  }

  const HandleBlog = () => {
    history.push('/blog')
  }

  const HandleAllBlog = () => {
    history.push('/allblog')
  }

  const handleSignup = () => {
    history.push('/signup')
  }

  return (
    <Box sx={{ flexGrow: 1 }} className="dark:bg-gray-800 z-50">
      <AppBar position="static" className="dark:bg-gray-800 z-50">
        <Toolbar className="dark:bg-gray-800 z-50">
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Typography
            variant="h6"
            component="div"
            sx={{ flexGrow: 1 }}
            className="cursor-pointer"
          >
            News
          </Typography>
          <Button>
            <div
              onClick={handleLogout}
              className="text-red-700 font-semibold text-xl"
            >
              Logout
            </div>
          </Button>

          <Button color="inherit" onClick={handleSide} className="relative">
            <ContactMailIcon />

            {isShown && (
              <div className="absolute top-10">
                <ul className=" mt-4 w-[165px] space-y-2 rounded-md bg-base-100 py-1 shadow">
                  <div className="cursor-pointer px-2" onClick={HandleLogin}>
                    <li className="inline-block rounded-md pr-1">
                      <Button className="flex items-center w-36 justify-center text-black rounded-md">
                        <LoginIcon className="mr-2 h-4 w-4 " />
                        Login
                        {/* <span className="text-sm sm:font-medium">
                        {userProfile}
                      </span> */}
                      </Button>
                    </li>
                  </div>
                  <div className="cursor-pointer px-2" onClick={handleSignup}>
                    <li>
                      <button className="items-start justify-start">
                        <li className="inline-block rounded-md pr-1">
                          <Button className="flex cursor-pointer items-center w-36 text-black justify-center rounded-md">
                            <LogoutIcon className="mr-2 h-4 w-4" />
                            Signup
                          </Button>
                        </li>
                      </button>
                    </li>
                  </div>
                </ul>
              </div>
            )}
          </Button>

          <Button color="inherit" onClick={HandleBlog}>
            MY BLOG
          </Button>
          <Button color="inherit" onClick={HandleAllBlog}>
            Add Blog
          </Button>
        </Toolbar>
      </AppBar>
    </Box>
  )
}
